export const stakingAddress = "0x51a925177d2d11b3962d8eC5fDE7ac38dC539C50";
export const tokenAddress = "0xA07C8a8d8575054066b10A7d2AFF663e5Eece1D5";
